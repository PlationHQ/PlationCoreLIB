import logging
from plationlogger import Logger, JsonFormatter, RotatingFileLogger, ConsoleLogger
from datetime import datetime
import os

# Create the logger instance
logger = Logger("PlationLoggerExample")

# Set logging level
logger.setLevel(logging.DEBUG)

# Add Console Handler with JSON formatter
console_handler = ConsoleLogger()
logger.addHandler(console_handler.get_handler())

# Add Rotating File Handler
rotating_file_handler = RotatingFileLogger("plation_log.log", max_bytes=10000, backup_count=3)
logger.addHandler(rotating_file_handler.get_handler())

# Logging example function
def log_example(logger):
    logger.debug("This is a debug message")
    logger.info("This is an info message")
    logger.warning("This is a warning message")
    logger.error("This is an error message")
    logger.critical("This is a critical message")
    
    # Simulate an exception
    try:
        x = 1 / 0
    except ZeroDivisionError:
        logger.exception("An exception occurred")

# Extended example with rotating file logging
def extended_log_example(logger):
    logger.debug("Debug level log")
    logger.info("Information log")
    logger.warning("Warning log")
    logger.error("Error level log")
    logger.critical("Critical issue log")

    # Simulating an exception
    try:
        result = 1 / 0
    except ZeroDivisionError as e:
        logger.exception("Division by zero occurred")

    # Log to rotating file
    logger.info("This message is logged to a rotating file.")

# Simulate logging multiple types of log messages
def simulate_logging(logger):
    # Simulate application start
    logger.info("Application started successfully.")
    logger.debug("Debugging some background operations.")
    logger.warning("Potential issue detected.")
    logger.error("An error occurred in processing.")
    logger.critical("Critical error! Application will stop.")
    
    try:
        open("non_existent_file.txt")
    except FileNotFoundError:
        logger.exception("File not found error occurred.")

    logger.info("Logging is complete.")

# Function to simulate a large number of debug logs (to test file rotation)
def simulate_file_rotation(logger):
    for i in range(1000):
        logger.debug(f"Test message {i+1}")

def main():
    # Run the basic logging example
    log_example(logger)

    # Run the extended logging example
    extended_log_example(logger)

    # Simulate logging from another part of the system
    simulate_logging(logger)

    # Simulate more operations to test file rotation
    simulate_file_rotation(logger)

if __name__ == "__main__":
    main()
