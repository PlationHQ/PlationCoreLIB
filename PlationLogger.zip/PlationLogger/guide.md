# PlationLogger Guide

**PlationLogger** is a flexible logging utility designed to provide structured and formatted output, making it easy to log messages with various levels of severity. It can output logs to various destinations, including the console, files, and even external services.

## Key Features
- **Custom Log Levels:** Define different levels for your logs like INFO, ERROR, DEBUG, etc.
- **Formatted Output:** Customize how your logs appear.
- **Multi-Destination Logging:** Logs can be output to multiple destinations like the console and files simultaneously.
- **Structured Logging:** Supports logging with JSON or custom formats.

## Installation

1. Clone the repository or download the source code:
    ```bash
    git clone <repository-url>
    ```


## Functions of PlationLogger

### 1. `Logger`
The `Logger` class is the core of **PlationLogger**. It allows you to configure different log destinations, set log levels, and apply custom formats.

- **Constructor:**
    ```python
    logger = Logger(name="MyLogger")
    ```

    - `name`: The name of the logger. You can provide any string here to uniquely identify the logger instance.

### 2. `addHandler`
The `addHandler` method allows you to define where the logs will be sent (e.g., console, file, external service).

- **Usage:**
    ```python
    logger.addHandler(handler)
    ```

    You can add different handlers like `StreamHandler` for the console or `FileHandler` for a log file.

    Example of adding a `StreamHandler`:
    ```python
    console_handler = StreamHandler()
    logger.addHandler(console_handler)
    ```

    Example of adding a `FileHandler`:
    ```python
    file_handler = FileHandler("logfile.log")
    logger.addHandler(file_handler)
    ```

### 3. `setLevel`
This method sets the minimum log level for the logger. Only logs that are at or above this level will be processed.

- **Usage:**
    ```python
    logger.setLevel(logging.INFO)
    ```

    Supported log levels include:
    - `logging.DEBUG`
    - `logging.INFO`
    - `logging.WARNING`
    - `logging.ERROR`
    - `logging.CRITICAL`

### 4. `log`
The `log` method logs messages at a specified level.

- **Usage:**
    ```python
    logger.log(level, message)
    ```

    Example:
    ```python
    logger.log(logging.INFO, "This is an info message")
    ```

### 5. `debug`
The `debug` method logs a message with the `DEBUG` level.

- **Usage:**
    ```python
    logger.debug("This is a debug message")
    ```

### 6. `info`
The `info` method logs a message with the `INFO` level.

- **Usage:**
    ```python
    logger.info("This is an info message")
    ```

### 7. `warning`
The `warning` method logs a message with the `WARNING` level.

- **Usage:**
    ```python
    logger.warning("This is a warning message")
    ```

### 8. `error`
The `error` method logs a message with the `ERROR` level.

- **Usage:**
    ```python
    logger.error("This is an error message")
    ```

### 9. `critical`
The `critical` method logs a message with the `CRITICAL` level.

- **Usage:**
    ```python
    logger.critical("This is a critical message")
    ```

### 10. `exception`
The `exception` method logs an exception message. This is typically used in exception handling blocks.

- **Usage:**
    ```python
    logger.exception("An exception occurred")
    ```

---

## Example Code (example.py)

```python
from plationlogger import Logger
import logging

# Create logger instance
logger = Logger(name="MyAppLogger")

# Add a console handler
console_handler = logging.StreamHandler()
logger.addHandler(console_handler)

# Set log level
logger.setLevel(logging.DEBUG)

# Logging messages
logger.debug("This is a debug message")
logger.info("This is an info message")
logger.warning("This is a warning message")
logger.error("This is an error message")
logger.critical("This is a critical message")

try:
    x = 1 / 0
except ZeroDivisionError:
    logger.exception("An exception occurred")
