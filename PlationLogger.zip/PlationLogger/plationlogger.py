import logging
import json
import os
from logging.handlers import RotatingFileHandler
from datetime import datetime

# Basic Logger class for PlationLogger
class Logger:
    def __init__(self, name):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.DEBUG)  # Default level to DEBUG
        self.handlers = []

    def addHandler(self, handler):
        """Add a handler (Console, File, etc.) to the logger."""
        self.handlers.append(handler)
        self.logger.addHandler(handler)

    def setLevel(self, level):
        """Set the minimum logging level for the logger."""
        self.logger.setLevel(level)

    def log(self, level, message):
        """Log a message at the specified log level."""
        self.logger.log(level, message)

    def debug(self, message):
        """Log a message at the DEBUG level."""
        self.logger.debug(message)

    def info(self, message):
        """Log a message at the INFO level."""
        self.logger.info(message)

    def warning(self, message):
        """Log a message at the WARNING level."""
        self.logger.warning(message)

    def error(self, message):
        """Log a message at the ERROR level."""
        self.logger.error(message)

    def critical(self, message):
        """Log a message at the CRITICAL level."""
        self.logger.critical(message)

    def exception(self, message):
        """Log an exception at the ERROR level."""
        self.logger.exception(message)

# Custom Formatter for structured logging (JSON format)
class JsonFormatter(logging.Formatter):
    def format(self, record):
        log_data = {
            "level": record.levelname,
            "message": record.getMessage(),
            "time": self.formatTime(record, "%Y-%m-%d %H:%M:%S"),
            "logger": record.name
        }
        return json.dumps(log_data)

# Custom Formatter for custom plain text logging
class CustomFormatter(logging.Formatter):
    def format(self, record):
        return f"{record.levelname} - {record.name}: {record.getMessage()}"

# Set up rotating file handler
class RotatingFileLogger:
    def __init__(self, file_name, max_bytes=10000, backup_count=3):
        self.handler = RotatingFileHandler(file_name, maxBytes=max_bytes, backupCount=backup_count)
        self.handler.setFormatter(CustomFormatter('%(asctime)s - %(levelname)s - %(message)s'))
        
    def get_handler(self):
        return self.handler

# Console handler setup with JSON format
class ConsoleLogger:
    def __init__(self):
        self.handler = logging.StreamHandler()
        self.handler.setFormatter(JsonFormatter())
        
    def get_handler(self):
        return self.handler

# Example function for logging various levels
def log_example(logger):
    logger.debug("This is a debug message")
    logger.info("This is an info message")
    logger.warning("This is a warning message")
    logger.error("This is an error message")
    logger.critical("This is a critical message")

    try:
        x = 1 / 0
    except ZeroDivisionError:
        logger.exception("An exception occurred")

# Extended example with rotating file logging
def extended_log_example(logger):
    logger.debug("Debug level log")
    logger.info("Information log")
    logger.warning("Warning log")
    logger.error("Error level log")
    logger.critical("Critical issue log")
    
    # Simulating an exception
    try:
        result = 1 / 0
    except ZeroDivisionError as e:
        logger.exception("Division by zero occurred")
    
    # Log to rotating file
    logger.info("This message is logged to a rotating file.")

# Main logging setup and execution
def main():
    # Initialize the logger
    logger = Logger(name="PlationLoggerExample")
    
    # Add console handler with JSON format
    console_logger = ConsoleLogger()
    logger.addHandler(console_logger.get_handler())
    
    # Add rotating file handler
    rotating_logger = RotatingFileLogger("plation_log.log")
    logger.addHandler(rotating_logger.get_handler())
    
    # Set logging level to INFO (This will log INFO, WARNING, ERROR, and CRITICAL)
    logger.setLevel(logging.INFO)

    # Run the basic logging example
    log_example(logger)
    
    # Run the extended logging example
    extended_log_example(logger)

    # Simulate logging from another part of the system
    logger.info("Application started successfully.")
    logger.debug("Debugging some background operations.")
    logger.warning("Potential issue detected.")
    logger.error("An error occurred in processing.")
    logger.critical("Critical error! Application will stop.")
    
    try:
        open("non_existent_file.txt")
    except FileNotFoundError:
        logger.exception("File not found error occurred.")

    logger.info("Logging is complete.")

    # Additional logging to test file rotation
    for i in range(1000):
        logger.debug(f"Test message {i+1}")
    
    # Simulating more operations
    logger.debug("Debugging system.")
    logger.info("System initialization completed.")
    logger.warning("Low disk space warning.")
    logger.error("Network failure error.")
    logger.critical("System crash imminent.")

if __name__ == "__main__":
    main()
