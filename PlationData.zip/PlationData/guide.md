# PlationData Guide  

## **Overview**  
**PlationData** is a Python library that provides utilities for seamless data manipulation, cleaning, and analysis. It integrates with **pandas** and **NumPy** for powerful data workflows.  

# PlationData Functions Guide

This document provides an overview of the functions in **PlationData**, including their descriptions and usage examples.

---

## **Normalize Column Names**  
Converts column names to lowercase and replaces spaces with underscores.

### Example usage:
To normalize column names in a DataFrame:
1. Use the `normalize_column_names()` function on the `columns` attribute.
2. The function will return the column names in lowercase with underscores instead of spaces.

---

## **Split Column**  
Splits a single column into multiple columns based on a delimiter.

### Example usage:
1. Use the `split_column()` function on the DataFrame to split a column into multiple columns.
2. Specify the original column, the new column names, and the delimiter to split on.
3. The function will split the original column into the new columns.

---

## **Join Columns**  
Joins multiple columns into one based on a separator.

### Example usage:
1. Use the `join_columns()` function on the DataFrame to combine multiple columns into one.
2. Specify the columns to combine, the new column name, and the separator.
3. The function will join the values in the specified columns using the given separator.

---

## **Fill Missing Values**  
Fills missing values in a specified column with a given value or method.

### Example usage:
1. Use the `fill_missing()` function on the DataFrame to fill missing values in a column.
2. Specify the column, and either a value or method (`'ffill'`, `'bfill'`, etc.) to fill missing values.
3. The function will fill missing values according to the specified method or value.

---

## **Remove Special Characters**  
Removes special characters from a specified text column.

### Example usage:
1. Use the `remove_special_characters()` function on the DataFrame to remove special characters from a text column.
2. Specify the column where special characters should be removed.
3. The function will clean the column by removing characters that are not alphanumeric or spaces.

---



