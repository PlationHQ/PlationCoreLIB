from plationdata import *

# Create a sample DataFrame
data = {
    "Full Name": ["Alice Johnson", "Bob Smith", "Charlie Davis", None],
    "Age": [25, 30, 35, None],
    "Score": [85, 90, 95, 88],
    "City": ["New York", "Los Angeles", "Chicago", "Houston"]
}
df = pd.DataFrame(data)

# Normalize column names
df.columns = normalize_column_names(df.columns)
print("Normalized Columns:\n", df)

# Fill missing values
df = fill_missing(df, "full_name", value="Unknown")
df = fill_missing(df, "age", value=df["age"].mean())
print("After Filling Missing Values:\n", df)

# Split and join columns
df = split_column(df, "full_name", ["first_name", "last_name"], " ")
df = join_columns(df, ["first_name", "last_name"], "rejoined_name", " ")
print("After Splitting and Joining Columns:\n", df)

# Inspect data
print("Summary Statistics:\n", summary_statistics(df))
print("Null Percentage:\n", column_null_percentage(df))
print("Unique Values Per Column:\n", unique_values_per_column(df))

# One-hot encoding
df = one_hot_encode(df, "city")
print("After One-Hot Encoding:\n", df)

# Create a random NumPy array and convert to a DataFrame
random_array = create_random_array(3, 4)
df_random = array_to_dataframe(random_array, ["Col1", "Col2", "Col3", "Col4"])
print("Random Array as DataFrame:\n", df_random)

# Save to CSV
save_csv(df, "output.csv")
print("DataFrame saved to output.csv")

# Plot data
plot_histogram(df, "age")
plot_scatter(df, "age", "score")
