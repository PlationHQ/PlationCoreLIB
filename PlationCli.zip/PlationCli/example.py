from plationcli import CLI

# Create an instance of the CLI tool
cli = CLI()

# Command to greet the user
@cli.command
def greet(name: str):
    """
    Greet the user by name.
    Usage: python example.py greet <name>
    """
    print(f"Hello, {name}!")

# Command to calculate the sum of two numbers
@cli.command
def sum_numbers(a: int, b: int):
    """
    Calculate the sum of two numbers.
    Usage: python example.py sum_numbers <a> <b>
    """
    result = a + b
    print(f"The sum of {a} and {b} is {result}")

# Command to calculate the factorial of a number
@cli.command
def factorial(n: int):
    """
    Calculate the factorial of a number.
    Usage: python example.py factorial <n>
    """
    result = 1
    for i in range(1, n + 1):
        result *= i
    print(f"The factorial of {n} is {result}")

# Command to display the user's information
@cli.command
def user_info(name: str, age: int):
    """
    Display the user's name and age.
    Usage: python example.py user_info <name> <age>
    """
    print(f"User Info: Name: {name}, Age: {age}")

# Parent command: main
@cli.command
def main():
    """
    Main command for the CLI tool.
    Usage: python example.py main
    """
    print("This is the main command.")

# Subcommand under 'main' command
@cli.command
def subcommand(arg: str):
    """
    A subcommand for the 'main' command.
    Usage: python example.py main subcommand <arg>
    """
    print(f"This is a subcommand with argument: {arg}")

# Run the CLI tool
if __name__ == "__main__":
    cli.run()
