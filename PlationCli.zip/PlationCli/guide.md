# PlationCLI Guide

**PlationCLI** is a library designed to simplify the creation of command-line tools with intuitive wrappers, making it easier to define commands, subcommands, and handle arguments.

## Key Features
- **Command Creation:** Define commands using decorators.
- **Subcommand Handling:** Group related commands with subcommands.
- **Argument Parsing:** Supports different types of command-line arguments.
- **Help Support:** Automatically provides help for commands and arguments.

## Installation

1. Clone the repository or download the source code:
    ```bash
    git clone <repository-url>
    ```



## Functions in PlationCLI Library

### 1. `CLI`
The `CLI` class is the core of **PlationCLI**. It handles the registration of commands, subcommands, and argument parsing.

- **Constructor:**
    - `cli = CLI()`  
    Creates a new instance of the CLI tool.

- **Method: `run()`**
    - **Description:** Executes the command-line interface and processes user inputs.
    - **Usage:**  
        The `run()` method is typically called at the end of your script to run the defined CLI application.

    Example:
    ```bash
    python example.py
    ```

### 2. `command`
The `command` decorator is used to define a command in your CLI tool.

- **Usage:**
    - `@cli.command`  
    Defines a function as a command in your CLI tool. The function will be triggered when the command is invoked.

- **Example:**
    ```bash
    @cli.command
    def greet(name):
        print(f"Hello, {name}!")
    ```

    In this example, the command `greet` will print a greeting message when executed.

### 3. `subcommand`
A subcommand allows you to define a command that belongs to a parent command. It helps to organize commands under a main command.

- **Usage:**
    - `@main.command`  
    Defines a subcommand under the `main` command.

- **Example:**
    ```bash
    @cli.command
    def main():
        pass

    @main.command
    def subcommand(arg):
        print(f"This is a subcommand with argument: {arg}")
    ```

    **Usage:**
    ```bash
    python example.py main subcommand test
    ```

### 4. `argument`
Arguments allow you to pass data to the commands. The `argument` decorator allows you to define the arguments for each command.

- **Usage:**
    - `@cli.argument(<name>, <type>, <optional/required>)`
    
    Example:
    ```bash
    @cli.command
    @cli.argument('name', str)
    def greet(name):
        print(f"Hello, {name}!")
    ```

    The `greet` command requires the argument `name`.

### 5. `help`
Each command can have a help message that is displayed when the user runs the `--help` flag or asks for command information.

- **Usage:**
    - `@cli.command(help="Description of the command")`  
    Adds a help description for your command.

    Example:
    ```bash
    @cli.command(help="This command greets the user.")
    def greet(name):
        print(f"Hello, {name}!")
    ```

### 6. `option`
The `option` decorator allows you to define options for your commands, which are flags that modify the command’s behavior. Options are optional and usually used for Boolean flags or other modifiers.

- **Usage:**
    - `@cli.option(<name>, <type>, <default>)`  
    Defines an option for your command.

    Example:
    ```bash
    @cli.command
    @cli.option('verbose', bool, default=False)
    def greet(name, verbose):
        if verbose:
            print(f"Hello, {name}! This is a verbose greeting.")
        else:
            print(f"Hello, {name}!")
    ```

    **Usage:**  
    ```bash
    python example.py greet John --verbose
    ```

    This command will print a verbose greeting if `--verbose` is used.

### 7. `argument_types`
The `argument_types` decorator allows you to specify the data type of arguments in a more flexible way.

- **Usage:**
    - `@cli.argument_types(<name>, <type>)`
    
    Example:
    ```bash
    @cli.command
    @cli.argument('num', int)
    def add(num):
        print(f"The number is {num}.")
    ```

### 8. `error_handling`
PlationCLI allows for custom error handling, so you can manage exceptions gracefully within your commands.

- **Usage:**  
    By using `try-except` within your command functions, you can catch and handle errors as needed.

    Example:
    ```bash
    @cli.command
    def divide(a, b):
        try:
            result = a / b
            print(f"The result is {result}.")
        except ZeroDivisionError:
            print("Error: Division by zero!")
    ```

### 9. `version`
If you want to display the version of your tool, PlationCLI supports a version option.

- **Usage:**
    - `@cli.version('<version-number>')`
    
    Example:
    ```bash
    @cli.version('1.0.0')
    def version():
        print("Tool version: 1.0.0")
    ```

    **Usage:**  
    ```bash
    python example.py --version
    ```

### 10. `help_command`
By default, every command in PlationCLI can display help information. If you want to create custom help commands, you can define the `help_command`.

- **Usage:**
    - `@cli.help_command(<command>)`
    
    Example:
    ```bash
    @cli.command
    @cli.help_command('greet')
    def help_greet():
        print("This command greets the user.")
    ```

## Conclusion

**PlationCLI** makes it easy to create complex and structured command-line tools by providing decorators for commands, subcommands, arguments, and options. The library allows you to quickly define commands and handle arguments in an intuitive way. 

With built-in support for help messages, versioning, and error handling, **PlationCLI** is a powerful tool for creating CLI applications.
