# PlationCLI.py - Simplified Command-Line Tool Creation

import sys
import inspect

class CLI:
    def __init__(self):
        self.commands = {}
        self.subcommands = {}

    def command(self, func):
        command_name = func.__name__
        self.commands[command_name] = func
        return func

    def subcommand(self, parent_command):
        def wrapper(func):
            if parent_command not in self.subcommands:
                self.subcommands[parent_command] = {}
            command_name = func.__name__
            self.subcommands[parent_command][command_name] = func
            return func
        return wrapper

    def run(self):
        if len(sys.argv) < 2:
            print("No command provided. Use '--help' for help.")
            return

        command_name = sys.argv[1]

        if command_name == '--help':
            self.display_help()
            return

        if command_name not in self.commands and command_name not in self.subcommands:
            print(f"Unknown command: {command_name}. Use '--help' for help.")
            return

        if command_name in self.commands:
            command = self.commands[command_name]
            args = sys.argv[2:]
            self._execute_command(command, args)
        elif command_name in self.subcommands:
            parent_command = sys.argv[2]
            if parent_command not in self.subcommands[command_name]:
                print(f"Unknown subcommand: {parent_command}. Use '--help' for help.")
                return
            subcommand = self.subcommands[command_name][parent_command]
            args = sys.argv[3:]
            self._execute_command(subcommand, args)

    def _execute_command(self, command, args):
        signature = inspect.signature(command)
        params = signature.parameters
        try:
            bound_args = signature.bind(*args)
            command(*bound_args.args)
        except Exception as e:
            print(f"Error: {e}")
            return

    def display_help(self):
        print("Available commands:")
        for command_name, command_func in self.commands.items():
            print(f"{command_name}: {command_func.__doc__.strip()}")
        print("\nSubcommands:")
        for parent_command, subcommands in self.subcommands.items():
            for subcommand_name, subcommand_func in subcommands.items():
                print(f"{parent_command} {subcommand_name}: {subcommand_func.__doc__.strip()}")

# CLI tool example
cli = CLI()

# Command to greet a user
@cli.command
def greet(name: str):
    """
    Greet the user with a provided name.
    Usage: python PlationCLI.py greet <name>
    """
    print(f"Hello, {name}!")

# Command to sum two numbers
@cli.command
def sum_numbers(a: int, b: int):
    """
    Calculate the sum of two numbers.
    Usage: python PlationCLI.py sum_numbers <a> <b>
    """
    result = a + b
    print(f"The sum of {a} and {b} is {result}")

# Command to calculate factorial
@cli.command
def factorial(n: int):
    """
    Calculate the factorial of a number.
    Usage: python PlationCLI.py factorial <n>
    """
    result = 1
    for i in range(1, n + 1):
        result *= i
    print(f"The factorial of {n} is {result}")

# Command to display user’s info
@cli.command
def user_info(name: str, age: int):
    """
    Display a user’s information.
    Usage: python PlationCLI.py user_info <name> <age>
    """
    print(f"User Info: Name: {name}, Age: {age}")

# Command to display system info
@cli.command
def system_info():
    """
    Display basic system information.
    Usage: python PlationCLI.py system_info
    """
    import platform
    print(f"System: {platform.system()}")
    print(f"Release: {platform.release()}")
    print(f"Version: {platform.version()}")

# Command to show current time
@cli.command
def current_time():
    """
    Show the current system time.
    Usage: python PlationCLI.py current_time
    """
    from datetime import datetime
    now = datetime.now()
    print(f"Current time: {now.strftime('%Y-%m-%d %H:%M:%S')}")

# Command to concatenate strings
@cli.command
def concatenate(*args: str):
    """
    Concatenate multiple strings together.
    Usage: python PlationCLI.py concatenate <string1> <string2> ...
    """
    result = " ".join(args)
    print(f"Concatenated string: {result}")

# Command to repeat a string multiple times
@cli.command
def repeat_string(word: str, count: int):
    """
    Repeat a string multiple times.
    Usage: python PlationCLI.py repeat_string <word> <count>
    """
    print(f"Repeated string: {word * count}")

# Parent command
@cli.command
def main():
    """
    Main command for the CLI tool.
    Usage: python PlationCLI.py main
    """
    print("This is the main command.")

# Subcommand under 'main' command
@cli.subcommand('main')
def subcommand(arg: str):
    """
    A subcommand under the 'main' command.
    Usage: python PlationCLI.py main subcommand <arg>
    """
    print(f"This is a subcommand with argument: {arg}")

# Command to validate email format
@cli.command
def validate_email(email: str):
    """
    Validate an email format using a regex pattern.
    Usage: python PlationCLI.py validate_email <email>
    """
    import re
    pattern = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
    if re.match(pattern, email):
        print(f"{email} is a valid email address.")
    else:
        print(f"{email} is not a valid email address.")

# Command to validate URL format
@cli.command
def validate_url(url: str):
    """
    Validate a URL format using a regex pattern.
    Usage: python PlationCLI.py validate_url <url>
    """
    import re
    pattern = r"^(http|https):\/\/[a-zA-Z0-9.-]+(?:\/[^\s]*)?$"
    if re.match(pattern, url):
        print(f"{url} is a valid URL.")
    else:
        print(f"{url} is not a valid URL.")

# Command to show system memory usage
@cli.command
def memory_usage():
    """
    Display system memory usage.
    Usage: python PlationCLI.py memory_usage
    """
    import psutil
    memory = psutil.virtual_memory()
    print(f"Total memory: {memory.total / (1024 ** 3):.2f} GB")
    print(f"Used memory: {memory.used / (1024 ** 3):.2f} GB")
    print(f"Free memory: {memory.free / (1024 ** 3):.2f} GB")

# Run the CLI tool
if __name__ == "__main__":
    cli.run()
