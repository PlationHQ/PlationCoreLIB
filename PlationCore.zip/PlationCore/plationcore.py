"""
PlationCore: Foundation for common utilities and reusable functions.

Author: Aaditya Pandey
License: MIT
"""

# -------------------------------
# IMPORTS
# -------------------------------
import math
import os
import random
import string
import re
from datetime import datetime, timedelta
from collections import Counter
from itertools import islice

# -------------------------------
# STRING UTILITIES
# -------------------------------

def capitalize_words(sentence):
    """Capitalize the first letter of every word in a string."""
    return ' '.join(word.capitalize() for word in sentence.split())

def reverse_string(s):
    """Reverse a given string."""
    return s[::-1]

def is_palindrome(s):
    """Check if a string is a palindrome."""
    # Clean the input by removing non-alphanumeric characters and converting to lowercase
    clean_s = re.sub(r'[^a-zA-Z0-9]', '', s).lower()
   
    return clean_s == clean_s[::-1]

def count_vowels(s):
    """Count the number of vowels in a string."""
    return sum(1 for char in s.lower() if char in 'aeiou')

def remove_whitespace(s):
    """Remove all whitespace from a string."""
    return ''.join(s.split())

# -------------------------------
# MATH UTILITIES
# -------------------------------

def is_prime(num):
    """Check if a number is a prime."""
    if num <= 1:
        return False
    for i in range(2, int(math.sqrt(num)) + 1):
        if num % i == 0:
            return False
    return True

def gcd(a, b):
    """Calculate the greatest common divisor of two numbers."""
    while b:
        a, b = b, a % b
    return a

def lcm(a, b):
    """Calculate the least common multiple of two numbers."""
    return abs(a * b) // gcd(a, b) if a and b else 0

def factorial(n):
    """Calculate the factorial of a number."""
    return 1 if n <= 1 else n * factorial(n - 1)

def fib_sequence(n):
    """Generate the first n numbers of the Fibonacci sequence."""
    a, b = 0, 1
    result = []
    for _ in range(n):
        result.append(a)
        a, b = b, a + b
    return result

# -------------------------------
# RANDOM UTILITIES
# -------------------------------

def generate_random_string(length=8):
    """Generate a random string of given length."""
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

def random_int_list(size, start=0, end=100):
    """Generate a list of random integers."""
    return [random.randint(start, end) for _ in range(size)]

def shuffle_list(lst):
    """Randomly shuffle the elements of a list."""
    shuffled = lst[:]
    random.shuffle(shuffled)
    return shuffled

# -------------------------------
# DATE UTILITIES
# -------------------------------

def current_timestamp():
    """Return the current timestamp as a formatted string."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def add_days_to_date(date_str, days):
    """Add a number of days to a date (YYYY-MM-DD)."""
    date = datetime.strptime(date_str, "%Y-%m-%d")
    return (date + timedelta(days=days)).strftime("%Y-%m-%d")

def days_between_dates(date1, date2):
    """Calculate the number of days between two dates."""
    d1 = datetime.strptime(date1, "%Y-%m-%d")
    d2 = datetime.strptime(date2, "%Y-%m-%d")
    return abs((d2 - d1).days)

def format_date(date, fmt="%B %d, %Y"):
    """Format a date object into a given string format."""
    return date.strftime(fmt)

# -------------------------------
# FILE UTILITIES
# -------------------------------

def read_file(filepath):
    """Read and return the content of a file."""
    if not os.path.exists(filepath):
        raise FileNotFoundError("File does not exist.")
    with open(filepath, 'r') as file:
        return file.read()

def write_file(filepath, content):
    """Write content to a file."""
    with open(filepath, 'w') as file:
        file.write(content)

def append_to_file(filepath, content):
    """Append content to a file."""
    with open(filepath, 'a') as file:
        file.write(content)

def count_words_in_file(filepath):
    """Count the number of words in a file."""
    content = read_file(filepath)
    return len(content.split())

# -------------------------------
# COLLECTION UTILITIES
# -------------------------------

def most_common_elements(iterable, n=1):
    """Return the n most common elements from an iterable."""
    return Counter(iterable).most_common(n)

def unique_elements(iterable):
    """Return a list of unique elements from an iterable."""
    return list(set(iterable))

def partition_list(lst, predicate):
    """Partition a list based on a predicate function."""
    true_list, false_list = [], []
    for item in lst:
        (true_list if predicate(item) else false_list).append(item)
    return true_list, false_list

def sliding_window(iterable, n):
    """Generate a sliding window of size n from an iterable."""
    it = iter(iterable)
    result = tuple(islice(it, n))
    if len(result) == n:
        yield result
    for elem in it:
        result = result[1:] + (elem,)
        yield result

# -------------------------------
# HELPER UTILITIES
# -------------------------------

def flatten_list(nested_list):
    """Flatten a nested list."""
    return [item for sublist in nested_list for item in sublist]

def chunks(lst, chunk_size):
    """Divide a list into chunks of a given size."""
    for i in range(0, len(lst), chunk_size):
        yield lst[i:i + chunk_size]

def merge_dicts(*dicts):
    """Merge multiple dictionaries."""
    merged = {}
    for d in dicts:
        merged.update(d)
    return merged

def safe_divide(a, b):
    """Safely divide two numbers, returning None if division by zero."""
    try:
        return a / b
    except ZeroDivisionError:
        return None

def map_reduce(lst, map_func, reduce_func):
    """Apply a map function and then a reduce function on a list."""
    mapped = map(map_func, lst)
    return reduce_func(mapped)

# -------------------------------
# MODULE INFO
# -------------------------------
__all__ = [
    "capitalize_words", "reverse_string", "is_palindrome", "count_vowels",
    "remove_whitespace", "is_prime", "gcd", "lcm", "factorial", "fib_sequence",
    "generate_random_string", "random_int_list", "shuffle_list", "current_timestamp",
    "add_days_to_date", "days_between_dates", "format_date", "read_file",
    "write_file", "append_to_file", "count_words_in_file", "most_common_elements",
    "unique_elements", "partition_list", "sliding_window", "flatten_list",
    "chunks", "merge_dicts", "safe_divide", "map_reduce"
]
