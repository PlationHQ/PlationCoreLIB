# Importing functions from PlationCore
from plationcore import (
    capitalize_words, reverse_string, is_palindrome, count_vowels,
    is_prime, gcd, lcm, fib_sequence, generate_random_string, 
    random_int_list, current_timestamp, add_days_to_date, 
    days_between_dates, read_file, write_file, count_words_in_file,
    most_common_elements, unique_elements, flatten_list, chunks,
    safe_divide, shuffle_list
)

# String utilities
sentence = "hello from plation core"
print("Capitalized words:", capitalize_words(sentence))
print("Reversed string:", reverse_string(sentence))
print("Is 'racecar' a palindrome?", is_palindrome("racecar"))
print("Number of vowels in sentence:", count_vowels(sentence))

# Math utilities
print("Is 29 prime?", is_prime(29))
print("GCD of 56 and 98:", gcd(56, 98))
print("LCM of 12 and 15:", lcm(12, 15))
print("First 10 Fibonacci numbers:", fib_sequence(10))

# Random utilities
print("Random string (length 10):", generate_random_string(10))
print("Random list of integers:", random_int_list(5, 1, 50))
sample_list = [1, 2, 3, 4, 5]
print("Shuffled list:", shuffle_list(sample_list))

# Date utilities
print("Current timestamp:", current_timestamp())
print("Add 10 days to '2024-12-05':", add_days_to_date("2024-12-05", 10))
print("Days between '2024-12-05' and '2024-12-25':", days_between_dates("2024-12-05", "2024-12-25"))

# File utilities
write_file("test_file.txt", "Welcome to PlationCore examples!")
print("File content:", read_file("test_file.txt"))
print("Word count in file:", count_words_in_file("test_file.txt"))

# Collection utilities
example_list = [1, 2, 2, 3, 3, 3, 4]
print("Most common elements:", most_common_elements(example_list, 2))
print("Unique elements:", unique_elements(example_list))

# Helper utilities
nested_list = [[1, 2], [3, 4], [5, 6]]
print("Flattened list:", flatten_list(nested_list))
print("Chunks of size 2:", list(chunks([1, 2, 3, 4, 5], 2)))
print("Safe divide 10 / 2:", safe_divide(10, 2))
print("Safe divide 10 / 0:", safe_divide(10, 0))
